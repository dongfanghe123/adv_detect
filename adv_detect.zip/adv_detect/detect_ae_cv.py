import argparse
import tensorflow as tf


from utils.setup_cicids import CICIDS, CICIDSModel, CICIDSAEModel
import numpy as np
import math
import random
# from setup_inception import ImageNet, InceptionModel

from sklearn import metrics
from utils.classifier import  get_success_advs, random_select
from utils.classifier import get_correctly_pred_data
from sklearn.metrics import auc,roc_curve
import matplotlib
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier


def get_args():
    parser = argparse.ArgumentParser()
    # parser.add_argument("--save_filepath", type=str, default='result/uncertainty6.csv')
    parser.add_argument("--threshold", type=int, default=0.01)
    parser.add_argument("--modify_variants", type=int, default=3)
    parser.add_argument("--max_modify_num", type=int, default=200)
    parser.add_argument("--modify_value", type=int, default=0.015)  # mnist 0.3 # cicids 0.0006
    parser.add_argument("--attack", type=str, default='fgsm-cicids')
    parser.add_argument("--dataset", type=str, default='cicids')
    parser.add_argument('--change_threshold', type=float, default=0.01, help=' percentage of change in each feature')
    parser.add_argument('--intrusion_category', type=int, default=4)
    args = parser.parse_args()

    return args


if __name__ == '__main__':


    # for attack in ['fgsm-cicids','bim-a-cicids','cw-cicids']:
    for attack in ['fgsm-cicids']:
        temp=[0.01]
        # if attack =='cw':
        #     temp=[0.1,0.4]
        for change_threshold in temp:

            args = get_args()
            args.dataset = 'cicids_binary'
            args.attack=attack
            args.intrusion_category = 1
            args.change_threshold = change_threshold
            print(args.attack)
            print(args.change_threshold)
            train_num=100000
            if args.dataset=='cicids':
                data, model_dir = CICIDS(), "models/cicids.h5"
                ae_model_dir = "models/CICIDSAE.h5"
            elif args.dataset=='cicids_binary':
                data, model_dir = CICIDS(attack_cat=args.intrusion_category,train_num=300000), "models/cicids_binary.h5"
                ae_model_dir = "models/CICIDSAE_binary.h5"


            file_name = '{}_{}_{}.npy'.format(args.dataset, args.attack, args.change_threshold)
            adv_samples = np.load('data/crafted_ae/Adv_' + file_name)
            labels = np.load('data/crafted_ae/labels_' + file_name)

            with tf.compat.v1.Session() as sess:
                # load model

                if 'cicids' in args.dataset:
                    model_to_attack = CICIDSModel(model_dir, sess)
                    cae = CICIDSAEModel(ae_model_dir, sess)
                elif 'cicids_binary' in args.dataset:
                    model = CICIDSModel(model_dir, sess, binary=True)
                    cae = CICIDSAEModel(ae_model_dir, sess)


                success_advs, labs_adv, _ = get_success_advs(model_to_attack.model, adv_samples, labels, target=0)


                X_test, Y_test, x_remain, y_remain, _ = get_correctly_pred_data(model_to_attack.model,
                                                                                data.test_data, data.test_labels)
                total_num = X_test.shape[0]
                idxs = random_select(total_num, len(success_advs))
                clean_samples = X_test[idxs]
                labs_clean = Y_test[idxs]


                success_advs = success_advs[np.argmax(labs_adv,axis=1)!=0]
                labs_adv = labs_adv[np.argmax(labs_adv,axis=1)!=0]
                clean_samples = clean_samples[np.argmax(labs_clean,axis=1) == 0]
                labs_clean = labs_clean[np.argmax(labs_clean,axis=1) == 0]


                samples = np.concatenate((success_advs, clean_samples))
                labs = np.concatenate((labs_adv, labs_clean))  # true label
                labs_ae_flag = np.concatenate((np.ones([len(success_advs), 1]), np.zeros([len(clean_samples), 1])))  # ae:1


                data_list=[]
                label_list=[]

                num=10

                for i in range(1, 4):
                    cicids = CICIDS(attack_cat=i, train_num=train_num,partial=True)
                    data_list.append(cicids.train_data)
                    label_list.append(cicids.train_labels)

                model_list = []
                for i in range(len(data_list)):
                    model = RandomForestClassifier(n_estimators=200)  #200 or 100
                    model.fit(data_list[i].reshape((data_list[i].shape[0], -1)), np.argmax(label_list[i], axis=1))
                    model_list.append(model)

                predictions = []
                for model in model_list:
                    prediction = model.predict_proba(samples.reshape(samples.shape[0], -1))
                    predictions.append(prediction)


                # temp = fun(predictions)

                cicids = CICIDS(attack_cat=1, train_num=train_num)
                normal_val = cicids.validation_data[np.argmax(cicids.validation_labels, axis=1) == 0]

                predictions_ = []
                for model in model_list:
                    prediction_ = model.predict_proba(normal_val.reshape(normal_val.shape[0], -1))
                    # prediction_=prediction_[prediction_[:, 0] > 0.7]
                    predictions_.append(prediction_)

                train = np.stack([array[:, 0] for array in predictions_], axis=1)

                from sklearn.ensemble import IsolationForest

                model = IsolationForest(random_state=42,contamination=0.0008)
                model.fit(train)

                train_score=model.decision_function(train)

                first_columns = [array[:, 0] for array in predictions]
                result = np.stack(first_columns, axis=1)


                prediction = model.predict(result)
                test_score=model.decision_function(result)
                from sklearn.metrics import classification_report
                #print(classification_report(np.concatenate((-np.ones(len(success_advs)), np.ones(len(clean_samples)))),prediction))

                t2 = np.full(len(success_advs), -1)
                t3 = np.ones(len(clean_samples))


                fpr4, tpr4, thresholds4 = roc_curve(np.concatenate((np.ones(len(success_advs)), np.zeros(len(clean_samples)))),
                                                    -test_score)
                auc_score4 = auc(fpr4, tpr4)

                print('IF auc=', auc_score4)


                plt.style.use('seaborn-dark')
                plt.figure(figsize=(6, 4.5))
                plt.plot(fpr4, tpr4, color='r', linestyle='--',linewidth=2,
                         label='ours (AUC = %0.4f)' % auc_score4)
                plt.legend(loc='lower right')
                plt.title("CW attack, Perturbation restriction={}%".format(int(args.change_threshold * 100)))
                plt.xlabel("FPR")
                plt.ylabel("TPR")
                plt.grid(linestyle='--', linewidth=1)
                #plt.savefig(r'{}_{}_{}_test.png'.format(args.dataset,args.attack,args.change_threshold),format='png',dpi=500,bbox_inches='tight')
                plt.show()
                plt.close()

                # plt.style.use('seaborn-dark')
                # plt.figure(figsize=(6, 4.5))
                #
                # plt.plot(fpr2, tpr2, color='k',linestyle=':',linewidth=2,
                #          label='Db (AUC = %0.4f)' % auc_score2)
                # plt.legend(loc='lower right')
                # plt.title("CW attack, Perturbation restriction={}%".format(int(args.change_threshold * 100)))
                # plt.xlabel("FPR")
                # plt.ylabel("TPR")
                # plt.grid(linestyle='--', linewidth=1)
                # #plt.savefig(r'figures/{}_{}_{}_test.png'.format(args.dataset,args.attack,args.change_threshold),format='png',dpi=500,bbox_inches='tight')
                # plt.show()
                # plt.close()