import os
import argparse
import numpy as np
import tensorflow as tf
# user define library
from utils.setup_NSL import NSL_KDD
from utils.setup_NSL import NSLModel
from utils import classifier as clf
from utils.classifier import  get_success_advs, random_select
from sklearn.metrics import auc,roc_curve
import matplotlib
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import cohen_kappa_score
def select_tree(rf,val_data,num_model):
    trees=rf.estimators_
    kappa_scores=[]
    predictions=[]
    for tree in trees:
        prediction=tree.predict(val_data)
        predictions.append(prediction)
    for i in range(len(trees)):
        scores=[]
        for j in range(len(trees)):
            prediciton1=predictions[i]
            prediciton2=predictions[j]
            score=cohen_kappa_score(prediciton1,prediciton2)
            scores.append(score)
        kappa_scores.append(scores)
    index=np.argpartition(kappa_scores, num_model)
    temp=np.array(kappa_scores)
    temp_=np.sum(temp,axis=1)
    index=np.argpartition(temp_,kth=num_model)[:num_model]
    result = [trees[i] for i in index]
    rf.estimators_ = result
    return rf

def subset_data(data):
    # to deal with memory error (use small subset of data)
    print('Train data: {}; Test Data: {}'.format(data.train_data.shape, data.test_data.shape))
    train_data = data.train_data[0:10000, :]
    test_data = data.test_data[0:5000, :]
    train_labels_one_hot = data.train_labels[0:10000]
    test_labels_one_hot = data.test_labels[0:5000]
    train_labels = np.argmax(train_labels_one_hot, 1)
    test_labels = np.argmax(test_labels_one_hot, 1)
    return train_data, test_data, train_labels, test_labels, train_labels_one_hot, test_labels_one_hot


def load_aes(attack,change_threshold):

    advs = np.load('data/crafted_ae/Adv_nsl-kdd_{}_{}.npy'.format(attack,change_threshold))
    true_labels = np.load('data/crafted_ae/labels_nsl-kdd_{}_{}.npy'.format(attack,change_threshold))
    return advs, true_labels

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--save_filepath", type=str, default='result/uncertainty7')
    parser.add_argument("--model_name", type=str, default='nsl_kdd_Dos.h5')
    parser.add_argument("--modify_variants", type=int, default=3)
    parser.add_argument("--max_modify_num", type=int, default=15)
    parser.add_argument("--modify_value", type=int, default=0.005)
    parser.add_argument("--dataset", type=str, default='nsl-kdd')
    parser.add_argument("--attack", type=str, default='fgsm')
    parser.add_argument("--iter_n", type=int, default=1)
    args = parser.parse_args()

    return args


if __name__=='__main__':

    for change_threshold in [0.2]:
        args = get_args()

        attack_list = [('DoS', 0.0), ('Probe', 2.0), ('R2L', 3.0), ('U2R', 4.0)]  # attack classes

        attack_class = [('DoS', 0.0)]

        args.attack='fgsm-nsl'
        args.change_threshold=change_threshold

        print(args.attack)
        print(args.change_threshold)

        data = NSL_KDD(attack_class)
        train_data, test_data, train_labels, test_labels, train_labels_one_hot, test_labels_one_hot = subset_data(data)
        features_num = train_data.shape[1]
        total_test_num = data.test_data.shape[0]


        model_dir = os.path.join("models", args.model_name)


        adv_samples, labels = load_aes(args.attack,args.change_threshold)

        with tf.compat.v1.Session() as sess:


            model_to_attack = NSLModel(model_dir, features_num, sess)


            success_advs, labs_adv, _ = get_success_advs(model_to_attack.model, adv_samples, labels)

            idxs = random_select(total_test_num, len(success_advs))
            clean_samples = data.test_data[idxs]
            labs_clean = data.test_labels[idxs]

            success_advs = success_advs[np.all(labs_adv == [1, 0], axis=1)]
            labs_adv = labs_adv[np.all(labs_adv == [1, 0], axis=1)]
            clean_samples = clean_samples[np.all(labs_clean == [0, 1], axis=1)]
            labs_clean = labs_clean[np.all(labs_clean == [0, 1], axis=1)]
            samples = np.concatenate((success_advs, clean_samples))
            labs = np.concatenate((labs_adv, labs_clean))  # true label
            labs_ae_flag = np.concatenate((np.ones([len(success_advs), 1]), np.zeros([len(clean_samples), 1])))  # ae:1

            dos = NSL_KDD([('DoS', 0.0)])
            probe = NSL_KDD([('Probe', 2.0)])


            data_lists = []
            label_lists = []
            model_lists1 = []
            data_lists.append(dos.train_data)
            data_lists.append(probe.train_data)
            label_lists.append(dos.train_labels)
            label_lists.append(probe.train_labels)


            for i in range(len(data_lists)):
                model1 = RandomForestClassifier(n_estimators=100)
                train = data_lists[i]
                label = np.argmax(label_lists[i], axis=1)
                model1.fit(train, label)
                model_lists1.append(model1)



            # for i in range(len(model_lists1)):
            #     model_lists1[i]=select_tree(model_lists1[i],data.validation_data,num_model=100)

            predictions1 = []

            for i in range(len(model_lists1)):
                model1=model_lists1[i]
                prediction1 = model1.predict_proba(samples)
                predictions1.append(prediction1)

            normal_val = data.validation_data[np.all(data.validation_labels == [0, 1], axis=1)]

            predictions1_ = []
            for i in range(len(model_lists1)):
                model1 = model_lists1[i]
                prediction1_ = model1.predict_proba(normal_val)
                predictions1_.append(prediction1_)

            temp_ = np.concatenate((predictions1_[0][:, 1], predictions1_[1][:, 1]))

            t1_ = predictions1_[0][:][:, 1]
            t2_ = predictions1_[1][:][:, 1]
            t_ = np.hstack((t1_.reshape(-1, 1), t2_.reshape(-1, 1)))

            #predictions1[0][:, 1]：
            temp = np.concatenate((predictions1[0][:, 1], predictions1[1][:, 1]))

            t1 = predictions1[0][:][:, 1]
            t2 = predictions1[1][:][:, 1]
            t = np.hstack((t1.reshape(-1, 1), t2.reshape(-1, 1)))

            # plt.scatter(predictions1[0][:len(success_advs)][:,1], predictions1[1][:len(success_advs)][:,1], s=10, c='red', marker='o', label='First 99 Points')
            # plt.scatter(predictions1[0][len(success_advs):][:,1], predictions1[1][len(success_advs):][:,1], s=10, c='blue', marker='o', label='Remaining Points')
            # plt.title('Scatter Plot of Data')
            # plt.xlabel('X')
            # plt.ylabel('Y')
            # plt.show()


            # t3 = fun(predictions1)
            # fpr3, tpr3, thresholds3 = roc_curve(labs_ae_flag, t3)
            # auc_score3 = auc(fpr3, tpr3)
            # print('sum auc=',auc_score3)

            from sklearn.ensemble import IsolationForest

            model = IsolationForest(random_state=42)

            model.fit(t_)
            prediction1 = model.decision_function(t)
            prediction = model.predict(t)



            fpr, tpr, thresholds = roc_curve(np.concatenate((np.ones(len(success_advs)), np.zeros(len(clean_samples)))),
                                             -prediction1)
            auc_score = auc(fpr, tpr)

            print('IF auc=', auc_score)

            plt.style.use('seaborn-dark')
            plt.figure(figsize=(6, 4.5))
            plt.plot(fpr, tpr, color='r', linestyle='--',linewidth=2,
                     label='ours (AUC = %0.4f)' % auc_score)
            plt.legend(loc='lower right')
            plt.title("FGSM attack, Perturbation restriction={}%".format(int(args.change_threshold * 100)))
            plt.xlabel("FPR")
            plt.ylabel("TPR")
            plt.grid(linestyle='--', linewidth=1)
            #plt.savefig(r'figures/{}_{}_{}_test.png'.format(args.dataset,args.attack,args.change_threshold),format='png',dpi=500,bbox_inches='tight')
            plt.show()
            plt.close()
