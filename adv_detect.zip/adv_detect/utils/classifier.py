from sklearn.svm import SVC 
from sklearn.naive_bayes import BernoulliNB 
from sklearn import tree
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.semi_supervised import LabelSpreading
from sklearn.ensemble import VotingClassifier
from sklearn.neural_network import MLPClassifier as MLP
from sklearn.metrics import roc_curve, auc
from sklearn import metrics

import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import numpy as np
import tensorflow as tf
import pandas as pd
import random

import seaborn as sns
import warnings

def get_success_advs(model, samples, true_labels, target=None):
    preds = model(samples).eval()
    if target is None:
        pos1 = np.where(np.argmax(preds, 1) != np.argmax(true_labels, 1))
    else:
        pos1 = np.where(np.argmax(preds, 1) == target)
    x_sel = samples[pos1]
    y_sel = true_labels[pos1]

    return x_sel, y_sel, pos1


def get_correctly_pred_data(model, x, y, target=None, target_not=None):
    # sample idx that is correctly predicted
    preds = model(x).eval()
    pos1 = np.where(np.argmax(preds, 1) == np.argmax(y, 1))
    x_sel_correct = x[pos1]
    y_sel_correct = y[pos1]

    if target is not None:
        # sample idx that is correctly predicted and matched to the target categories
        pos11 = np.where(np.argmax(y_sel_correct, 1) == target)
        x_sel = x_sel_correct[pos11]
        y_sel = y_sel_correct[pos11]
    elif target_not is not None:
        # sample idx that is correctly predicted and matched to the target categories
        pos11 = np.where(np.argmax(y_sel_correct, 1) != target_not)
        x_sel = x_sel_correct[pos11]
        y_sel = y_sel_correct[pos11]
    else:
        x_sel = x_sel_correct
        y_sel = y_sel_correct

    # the samples that are not correctly predicted
    pos2 = np.where(preds.argmax(1) != y.argmax(1))
    x_remain = x[pos2]
    y_remain = y[pos2]
    return x_sel, y_sel, x_remain, y_remain, pos1


def random_select(max, num):
    lst = [i for i in range(max)]
    random.shuffle(lst)
    idxs = lst[0:num]
    return idxs





